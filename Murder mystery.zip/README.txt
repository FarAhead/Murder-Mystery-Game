rules: 

If you fail a task, you must not come back until the next round of the game.

If your whole group is voting on kicking someone (icluding you) you must all agree on kicking the person.

This is a game of trust.

As an Jester you must pretend to be the murderer while not being the murderer.

As a murderer you try to not act suspicious, you may kill someone by message them the words: "You are dead."

If you die as an innocent or as a jester, you cannot come back until the next round.

If you are dead you must not unmuted until the end of the round.


agreement:

By downloading this you agree not to re-publish my game, I made this, if you're making a game just with a few modifications like my one, please mention me.

idea:

The idea from the game came from among us.

how to play:

You must download python (the programming language) to play the game.

