----------------------------------------------------------------------------------------------------------------------------------------

rules: 

If you fail a task, you must not come back until the next round of the game.

If your whole group is voting on kicking someone (including you) you must all agree on kicking the person.

This is a game of trust.

As a Jester you must pretend to be the murderer while not being the murderer.

As a murderer you try to not act suspicious, you may kill someone by message them the words: "You are dead."

If you die you must mute and type "I've been killed." in the group chat and don't unmute until the end of the round.

If you die as an innocent or as a jester, you cannot come back until the next round.

If you are dead you must not unmute until the end of the round.

If you get vote kicked out as a murderer the innocent win.

Those are the premade rules of course you can make your own rules.

----------------------------------------------------------------------------------------------------------------------------------------

agreement:

By downloading this you agree not to re-publish my game as yours, I made this game.

----------------------------------------------------------------------------------------------------------------------------------------

idea:

The idea from the game came from among us.

----------------------------------------------------------------------------------------------------------------------------------------