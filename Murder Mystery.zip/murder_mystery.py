import random
import time

d = [
    'Innocent',
    'Murderer',
    'Innocent',
    'Innocent',
    'Jester',
    'Innocent'
]

task = [
    "The quick brown fox jumps over the lazy dog.",
    "I am doing a task to help my team!",
    "I'm great at fake typing but in real life terrible.",
    "We can do anything we want to if we stick to it long enough.",
    "Take the risk or lose the chance.",
    "Good things happen to those who hustle.",
    "Each day provides its own gifts",
    "I would rather die on my feet than live on my knees.",
    "I am not young enough to know everything."
    #add more 
]



taks1 = random.choice(task)
taks2 = random.choice(task)
taks3 = random.choice(task)
taks4 = random.choice(task)
taks5 = random.choice(task)

h = random.choice(d)
print(h)
if h == 'Innocent':
    print('Your task is to vote out the murderer\n')
    print('Tip: Just know there might not even be a murderer or there might be more than one murderer.')
    print("\nClose the program to exit the game\n")
    print("Type out the sentence in the task.")

    d = input('\nTask 1: ' + taks1 + ': ')
    if d == taks1:
        print('Task 1/5 done.')
    else:
        print('Sorry, you messed up your task')
        time.sleep(2)
        quit()
    d1 = input('\nTask 2: ' + taks2 + ': ')
    if d1 == taks2:
        print("Task 2/5 done.")
    else:
        print('Sorry, you messed up your task')
        time.sleep(2)
        quit()

    d2 = input('\nTask 3: ' + taks3 + ': ')
    if d2 == taks3:
        print('Task 3/5 done.')

    else:
        print('Sorry, you messed up your task')
        time.sleep(2)
        quit()
    
    d3 = input('\nTask 4: ' + taks4 + ': ')
    if d3 == taks4:
        print("Task 4/5 done.")
    
    else:
        print('Sorry, you messed up your task')
        time.sleep(2)
        quit()
    
    d4 = input('\nTask 5: ' + taks5 + ': ')
    if d4 == taks5:
        print("Task 5/5 completed.\n")
        print("\nYou now may speak to your group.")
        print("If the murderer kills you by dming you 'You are dead.', you must type in the group chat: 'I have been killed', you must not say who it is, you have to go on mute.")
        quitr = input("")
        if quitr == 'quit':
            print("Quitting.")
            time.sleep(1)
            quit()
        else:
            time.sleep(100000)
    

elif h == 'Murderer':
    print('Your task is to convice everyone you\'re not the murderer and blame someone else!\n')
    print('Tip: Twist people\'s words, they might mess up.')
    print("To exit out of the program click on the x.\n")
    d = input('\nTask 1: ' + taks1 + ': ')#add 2 more tasks
    if d == taks1:
        print('Task 1/3 done.')
        time.sleep(1)
    else:
        print('Sorry, you messed up your task')
        time.sleep(2)
        quit()
    d2 = input('\nTask 2: ' + taks2 + ': ')
    if d2 == taks2:
        print("Task 2/3 done.")
    else:
        print("Sorry, you messed up your task.")
        time.sleep(2)
        quit()
    d3 = input('\nTask 3: ' + taks3 + ': ')
    if d3 == taks3:
        print("Task 3/3 done!")
        print("\nYou now may speak to your group.")
        print("\nTip: You can kill someone by saying this in their dms: You are dead.")
        print("\nOnce a person dies, the person must tell the group chat that they died, and keep muted for the rest of the round.")
        time.sleep(100000)

elif h == 'Jester':
    print('Your task is to convice everyone you\'re the murderer.\n')
    print('Tip: You are the jester you must play jester well to succeed.')
    print("To exit out of the program click on the x.\n")
    d = input('\nTask 1: ' + taks1 + ': ') #add 2 more tasks
    if d == taks1:
        print('Task 1/3')
        time.sleep(1)
    else:
        print('Sorry, you messed up your task')
        time.sleep(2)
        quit()
    d2 = input('\nTask 2: ' + taks2 + ': ')
    if d2 == taks2:
        print('Task 2/3')
    else:
        print('Sorry, you messed up your task')
        time.sleep(2)
        quit()
    d3 = input('\nTask 3: ' + taks3 + ': ')
    if d3 == taks3:
        print("Task 3/3 done!")
        print("\nYou now may speak to your group.")
        time.sleep(100000)
    else:
        print("Sorry, you messed up your task.")
        time.sleep(2)
        quit()